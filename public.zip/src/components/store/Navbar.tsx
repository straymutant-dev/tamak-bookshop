// STRAYMUTANT.DEV — Tamak Bookshop
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ShoppingBag, PanelLeft } from 'lucide-react';
import { useCart } from '@/lib/cart/CartContext';
import BrandMark from './BrandMark';
import { usePathname } from 'next/navigation';
import UserAvatar from '@/components/ui/UserAvatar';
import MobileDrawer from '@/components/ui/MobileDrawer';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import UserMenuDrawer, { type UserMenuItem } from './UserMenuDrawer';
import { signOutAction } from '@/lib/actions/auth';

export default function Navbar({
  userFullName = null,
  userRole = null,
  crossHostBase,
  notifications,
}: {
  userFullName?: string | null;
  userRole?: 'client' | 'vendor' | 'staff' | 'admin' | null;
  crossHostBase?: string;
  notifications?: React.ReactNode;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [confirmingLogout, setConfirmingLogout] = useState(false);
  const { totalCount } = useCart();
  const pathname = usePathname();
  const isLoggedIn = userFullName !== null;

    const resolveHref = (href: string) => (crossHostBase && href.startsWith('/store') ? `${crossHostBase}${href}` : href);

  const dashboardHref =
    userRole === 'admin' || userRole === 'staff'
      ? '/admin/dashboard'
      : userRole === 'vendor'
      ? '/vendor/dashboard'
      : userRole === 'client'
      ? '/account/dashboard'
      : '/';

  // Account links first, so a logged-in user can always get back to their dashboard.
  const accountLinks: { label: string; href: string }[] = [];
  if (isLoggedIn) {
    accountLinks.push({
      label: userRole === 'admin' || userRole === 'staff' ? 'Admin portal' : 'Dashboard',
      href: dashboardHref,
    });
    if (userRole === 'client' || userRole === 'vendor') {
      accountLinks.push({ label: 'My orders', href: '/account/orders' });
    }
  }

  const isActive = (href: string) => {
    const linkPath = new URL(href, 'https://tamak.local').pathname;
    return pathname === linkPath || (linkPath !== '/' && pathname.startsWith(`${linkPath}/`));
  };

  const NAV_LINKS = [
    ...accountLinks,
    { label: 'Books catalog', href: resolveHref('/store') },
    ...(isLoggedIn ? [] : [{ label: 'Wholesale accounts', href: '/auth/register?type=vendor' }]),
    { label: 'Track order', href: resolveHref('/store/track') },
    { label: 'About', href: '/about' },
  ];
  

  const extraItems: UserMenuItem[] = [];
  if (isLoggedIn) {
    extraItems.push({ label: 'Home', href: '/' });
    extraItems.push({ label: 'Track an order', href: resolveHref('/store/track') });
    if (userRole === 'client' || userRole === 'vendor') {
      extraItems.push({ label: 'My dashboard', href: dashboardHref });
      extraItems.push({ label: 'Order history', href: '/account/orders' });
    }
    if (userRole === 'vendor') {
      extraItems.push({ label: 'Wholesale cart', href: '/vendor/cart' });
    }
    if (userRole === 'staff' || userRole === 'admin') {
      extraItems.push({ label: 'Admin dashboard', href: '/admin/dashboard' });
    }
  }

  return (

    <header className="glass-nav">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">

        <Link href={dashboardHref} className="flex items-center shrink-0">
          <BrandMark className="h-8 sm:h-9 md:h-10" />
        </Link>

        <nav className="hidden items-center gap-1 text-sm md:flex lg:gap-2">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={isActive(link.href) ? 'page' : undefined}
              className={`flex min-h-10 items-center rounded-xl px-3 py-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-green ${
                isActive(link.href)
                  ? 'bg-brand-green font-medium text-white shadow-sm'
                  : 'text-ink-muted hover:bg-brand-green hover:text-white'
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <Link
            href={resolveHref('/store/cart')}
            aria-current={isActive('/store/cart') ? 'page' : undefined}
            className={`relative flex h-10 w-10 items-center justify-center rounded-xl transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-green ${
              isActive('/store/cart') ? 'bg-brand-green text-white' : 'text-ink hover:bg-brand-green hover:text-white'
            }`}
            aria-label="Cart"
          >
            <ShoppingBag size={22} strokeWidth={1.75} />
            {totalCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-accent-terracotta text-[10px] font-medium text-white">
                {totalCount}
              </span>
            )}
          </Link>

          {isLoggedIn && notifications}

          {isLoggedIn ? (
            <button onClick={() => setUserMenuOpen(true)} className="hidden md:block" aria-label="Account menu">
              <UserAvatar fullName={userFullName} className="h-9 w-9 text-sm" asLink={false} />
            </button>
          ) : (
            <Link
              href="/auth/login"
              className="hidden rounded-xl border border-brand-sage px-4 py-2 text-sm text-ink transition-colors hover:border-brand-green hover:bg-brand-green hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-green md:block"
            >
              Log in
            </Link>
          )}

          <button onClick={() => setMenuOpen(true)} className="text-ink md:hidden" aria-label="Open menu">
            <PanelLeft size={22} />
          </button>
        </div>
      </div>

      <MobileDrawer open={menuOpen} onClose={() => setMenuOpen(false)}>
        <Link href={dashboardHref} className="mb-6 flex items-center shrink-0" onClick={() => setMenuOpen(false)}>
          <BrandMark className="h-10" />
        </Link>

        {isLoggedIn && (
          <div className="mb-4 flex items-center gap-3">
            <UserAvatar fullName={userFullName} className="h-9 w-9 text-sm" asLink={false} />
            <span className="text-sm font-medium text-ink">{userFullName}</span>
          </div>
        )}
        
        <nav className="flex flex-col gap-1 text-sm">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={isActive(link.href) ? 'page' : undefined}
              className={`flex min-h-10 items-center rounded-xl px-3 py-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-green ${
                isActive(link.href)
                  ? 'bg-brand-green font-medium text-white shadow-sm'
                  : 'text-ink-muted hover:bg-brand-green hover:text-white'
              }`}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          {isLoggedIn ? (
            <>
              <div className="my-2 border-t border-border-beige" />
              <Link
                href={`/account/settings?from=${encodeURIComponent(pathname)}`}
                aria-current={isActive('/account/settings') ? 'page' : undefined}
                className={`flex min-h-10 items-center rounded-xl px-3 py-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-green ${
                  isActive('/account/settings')
                    ? 'bg-brand-green font-medium text-white shadow-sm'
                    : 'text-ink-muted hover:bg-brand-green hover:text-white'
                }`}
                onClick={() => setMenuOpen(false)}
              >
                Account settings
              </Link>
              <button
                onClick={() => {
                  setMenuOpen(false);
                  setConfirmingLogout(true);
                }}
                className="py-2 text-left text-accent-terracotta"
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <div className="my-2 border-t border-border-beige" />
              <Link
                href="/auth/login"
                aria-current={isActive('/auth/login') ? 'page' : undefined}
                className={`flex min-h-10 items-center rounded-xl px-3 py-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-green ${
                  isActive('/auth/login')
                    ? 'bg-brand-green font-medium text-white shadow-sm'
                    : 'text-ink-muted hover:bg-brand-green hover:text-white'
                }`}
                onClick={() => setMenuOpen(false)}
              >
                Log in
              </Link>
            </>
          )}
        </nav>
      </MobileDrawer>

      {isLoggedIn && (
        <UserMenuDrawer
          open={userMenuOpen}
          onClose={() => setUserMenuOpen(false)}
          fullName={userFullName}
          extraItems={extraItems}
        />
      )}

      <ConfirmDialog
        open={confirmingLogout}
        title="Log out?"
        message="You'll need to sign in again to access your account."
        confirmLabel="Log out"
        cancelLabel="Cancel"
        onCancel={() => setConfirmingLogout(false)}
        onConfirm={async () => {
          await signOutAction();
        }}
      />
    </header>
  );
}