// STRAYMUTANT.DEV — Tamak Bookshop
'use server';

import { createClient } from '@/lib/supabase/server';
import type { OrderDetails } from '@/lib/orderDetailsTypes';
import { fetchPaymentAccounts } from '@/lib/paymentAccounts';

type OrderItemRow = {
  id: string;
  quantity: number;
  unit_price_pesewas: number;
  line_total_pesewas: number;
  books: { title: string; author: string | null } | { title: string; author: string | null }[] | null;
};

/**
 * The exact books on one order. Uses the signed-in user's own session, so the
 * database rules decide who can see what: customers and vendors see only their
 * own orders; staff and admins see every order.
 */
export async function getOrderDetails(orderId: string): Promise<OrderDetails> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Please log in again');

  const { data: order, error } = await supabase
    .from('orders')
    .select(
      'id, order_number, user_id, payment_reported_at, created_at, payment_method, payment_status, payment_reference, cheque_number, fulfillment_type, delivery_address, delivery_notes, order_status, subtotal_pesewas, discount_pesewas, total_pesewas, contact_name, contact_phone, order_items(id, quantity, unit_price_pesewas, line_total_pesewas, books(title, author))'
    )
    .eq('id', orderId)
    .single();

  if (error || !order) throw new Error('Order not found');

  const isOwner = order.user_id === user.id;
  const awaitingPayment = order.payment_status === 'payment_pending';
  const paymentAccounts = isOwner && awaitingPayment ? await fetchPaymentAccounts(supabase) : [];

  return {
    id: order.id,
    orderNumber: order.order_number,
    createdAt: order.created_at,
    paymentMethod: order.payment_method,
    paymentStatus: order.payment_status,
    paymentReference: order.payment_reference,
    chequeNumber: order.cheque_number,
    fulfillmentType: order.fulfillment_type,
    deliveryAddress: order.delivery_address,
    deliveryNotes: order.delivery_notes,
    orderStatus: order.order_status,
    subtotalPesewas: order.subtotal_pesewas,
    discountPesewas: order.discount_pesewas,
    totalPesewas: order.total_pesewas,
    contactName: order.contact_name,
    contactPhone: order.contact_phone,
    isOwner,
    paymentReportedAt: order.payment_reported_at,
    paymentAccounts,
    items: (order.order_items ?? []).map((item: OrderItemRow) => {
      const book = Array.isArray(item.books) ? item.books[0] : item.books;
      return {
        id: item.id,
        title: book?.title ?? 'Unknown title',
        author: book?.author ?? null,
        quantity: item.quantity,
        unitPricePesewas: item.unit_price_pesewas,
        linePesewas: item.line_total_pesewas,
      };
    }),
  };
}